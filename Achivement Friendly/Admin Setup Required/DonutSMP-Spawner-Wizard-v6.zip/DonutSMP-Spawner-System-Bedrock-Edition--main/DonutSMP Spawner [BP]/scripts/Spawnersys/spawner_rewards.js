/**
 * spawner_rewards.js — kill-count spawner rewards.
 * Configure in spawner_config.js (KILL_REWARDS_ENABLED, KILLS_PER_SPAWNER).
 */
import { world, system } from "@minecraft/server";
import { KILL_REWARDS_ENABLED, KILLS_PER_SPAWNER } from "./spawner_config.js";
import { buildSpawnerItemStack, formatMobName } from "./spawner_vanilla.js";

const KEY = "dsmp_kill_progress"; // JSON { "minecraft:zombie": 37, ... }

function load(player) {
	try {
		const raw = player.getDynamicProperty(KEY);
		return typeof raw === "string" ? JSON.parse(raw) : {};
	} catch {
		return {};
	}
}

function giveItem(player, item) {
	const container = player.getComponent("minecraft:inventory")?.container;
	const leftover = container ? container.addItem(item) : item;
	if (leftover) player.dimension.spawnItem(leftover, player.location);
}

export function registerKillRewards() {
	if (!KILL_REWARDS_ENABLED) return;

	world.afterEvents.entityDie.subscribe((event) => {
		try {
			const killer = event.damageSource?.damagingEntity;
			if (!killer || killer.typeId !== "minecraft:player") return;
			const mobType = event.deadEntity?.typeId;
			const need = Number(KILLS_PER_SPAWNER[mobType]);
			if (!mobType || !(need > 0)) return;

			const progress = load(killer);
			let kills = (Number(progress[mobType]) || 0) + 1;
			let rewards = 0;
			while (kills >= need) {
				kills -= need;
				rewards++;
			}
			progress[mobType] = kills;
			killer.setDynamicProperty(KEY, JSON.stringify(progress));

			if (rewards > 0) {
				system.run(() => {
					try {
						giveItem(killer, buildSpawnerItemStack({ mobType, count: 1, buffer: {} }, rewards));
						killer.sendMessage(`§a[Spawners] ✔ ${need} ${formatMobName(mobType)} kills — you earned ${rewards}x ${formatMobName(mobType)} Spawner!`);
					} catch (e) {
						console.warn("[Rewards] couldn't give spawner:", e);
					}
				});
			} else {
				killer.onScreenDisplay.setActionBar(`§7${formatMobName(mobType)} kills: §e${kills}§7/§e${need}`);
			}
		} catch (e) {
			console.warn("[Rewards] entityDie handler failed:", e);
		}
	});
}

export default { registerKillRewards };
