/**
 * spawner_config.js
 *
 * Toggle between the two loot systems, and tune the numbers each one uses.
 * Only ONE system is ever active — "legacy" or "new" — there is no
 * dual-flag setup, so there's no way to leave this in a contradictory state.
 */

export const LOOT_SYSTEM = {
	// "legacy": every spawner rolls off its OWN count only
	//           (spawner_state.computeEffectiveRolls(state.count)).
	//           This is the original behavior — scattering unstacked
	//           spawners produces far more loot than stacking the same
	//           number into one block.
	//
	// "new":    an owner's spawners are judged by their TOTAL count across
	//           every block they own, stacked or scattered. Splitting a
	//           stack into separate blocks no longer produces more loot.
	active: "new",

	// Owners at or below this total spawner count always use the LEGACY
	// system, regardless of the "active" setting above. Keeps new/small
	// players on simple, predictable, generous behavior while the
	// fairness curve only kicks in once someone is playing at real scale.
	newbieProtectionThreshold: 10,
};

// Whether the plugin touches spawners it did NOT place itself — natural
// dungeon/vanilla-generated spawner blocks the player just finds in the
// world. When false (the default), those are left 100% vanilla:
//   - no watching what mob type they produce
//   - no special item when Silk Touch mined (vanilla's own rules apply,
//     which normally means it just doesn't drop at all)
//   - a spawn egg used on one does nothing special; plain vanilla egg
//     behavior applies instead
// The ONLY way to get a tracked spawner is to place one of the plugin's
// own spawner items (crafted/obtained through your economy/shop/admin
// tools) — never by finding and converting a wild one.
export const ALLOW_WILD_SPAWNER_INTERACTION = true;

// true = every spawner drops cooked food (cooked_beef, cooked_porkchop, cooked_mutton,
// cooked_chicken, cooked_cod, baked_potato). false = raw drops.
export const COOKED_DROPS = true;

// Who counts as an admin (gets the Admin Tool stick, can use /sm:givespawner,
// can configure spawners with an egg). Anyone who is a real operator qualifies
// automatically, as does anyone carrying the "admin" tag. BUT: worlds that keep
// achievements ON have cheats OFF, and then nobody is an operator — so list your
// gamertag(s) here (exact spelling, case-insensitive) to get the tool anyway.
export const ADMIN_GAMERTAGS = [
	// "YourGamertag",
];

// true = a player who does NOT qualify as admin is told (once per join) what the
// pack detected about them, so you can see why no stick was given. Turn this
// off (false) before running a public server.
export const ADMIN_DIAGNOSTICS = true;

// true  = the admin menu shows the "Give configured spawner" section (mob,
//         amount, player name + give button) at all times.
// false = that whole section is removed from the menu; only the setup steps remain.
export const SHOW_GIVE_CONFIGURED_SPAWNER_BUTTON = true;

// ── Kill rewards ──────────────────────────────────────────────────────
// Kill a mob this many times and you are given ONE configured spawner of that
// mob (progress is counted per player, per mob, and survives restarts).
// Only kills by a player count — mobs a spawner produces never do.
// A mob that isn't listed (or is set to 0) gives no reward. The numbers below
// are starting values: edit them freely, and add any mob that exists in
// spawner_loot.js.
export const KILL_REWARDS_ENABLED = true;

export const KILLS_PER_SPAWNER = {
	// Common hostiles
	"minecraft:zombie": 100,
	"minecraft:husk": 100,
	"minecraft:drowned": 100,
	"minecraft:skeleton": 100,
	"minecraft:stray": 100,
	"minecraft:spider": 100,
	"minecraft:cave_spider": 100,
	"minecraft:creeper": 100,
	"minecraft:enderman": 100,
	"minecraft:slime": 100,
	"minecraft:magma_cube": 100,
	// Uncommon
	"minecraft:silverfish": 150,
	"minecraft:witch": 150,
	"minecraft:blaze": 150,
	"minecraft:bogged": 150,
	"minecraft:zombified_piglin": 150,
	"minecraft:piglin": 150,
	"minecraft:hoglin": 150,
	// Rare
	"minecraft:wither_skeleton": 200,
	"minecraft:guardian": 200,
	"minecraft:evoker": 200,
	"minecraft:phantom": 200,
	"minecraft:breeze": 200,
	"minecraft:shulker": 250,
	"minecraft:ghast": 250,
	"minecraft:piglin_brute": 250,
	"minecraft:iron_golem": 250,
	// Boss-tier
	"minecraft:elder_guardian": 25,
	// Passive farm animals
	"minecraft:pig": 100,
	"minecraft:cow": 100,
	"minecraft:sheep": 100,
	"minecraft:chicken": 100,
};

export default { KILL_REWARDS_ENABLED, KILLS_PER_SPAWNER, SHOW_GIVE_CONFIGURED_SPAWNER_BUTTON, ADMIN_GAMERTAGS, ADMIN_DIAGNOSTICS, LOOT_SYSTEM, ALLOW_WILD_SPAWNER_INTERACTION, COOKED_DROPS };
