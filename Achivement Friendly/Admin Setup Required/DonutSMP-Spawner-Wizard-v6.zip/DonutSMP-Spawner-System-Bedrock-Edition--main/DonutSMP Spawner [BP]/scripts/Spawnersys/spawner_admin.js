/**
 * spawner_admin.js
 *
 * Admin distribution command: /sm:givespawner <target> [count] [mob]
 *
 * LIMITATION: with no [mob], this gives a BLANK, unconfigured spawner item. The
 * receiving player places it, then an admin uses a spawn egg on it to configure
 * the mob type (spawner_vanilla.js picks that up automatically).
 */

import * as mc from "@minecraft/server";
import { isAdminPlayer } from "../Modules/compat.js";
import { SPAWNER_ITEM_ID, buildSpawnerItemStack, formatMobName } from "./spawner_vanilla.js";

const { system, ItemStack, CustomCommandParamType, CustomCommandStatus } = mc;
// Stable 2.x renamed CustomCommandPermissionLevel -> CommandPermissionLevel;
// a namespace import lets us accept either without a load-time SyntaxError.
const PermissionLevel = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
/**
 * Custom command (stable @minecraft/server 2.1+):
 *   /sm:givespawner <target> [count] [mob]
 * Must be registered from system.beforeEvents.startup (see index.js).
 * Requires game-director (op) permission. The callback runs in a read-only
 * "before" context, so the actual item handout is deferred with system.run.
 */
export function registerCommands(startupEvent) {
	try {
	startupEvent.customCommandRegistry.registerCommand(
		{
			name: "sm:givespawner",
			description: "Give a player stacked-spawner items (blank, or pre-set to a mob)",
			permissionLevel: PermissionLevel.Any, // real gate is isAdminPlayer() below (cheats-off worlds have no ops)
			mandatoryParameters: [{ type: CustomCommandParamType.PlayerSelector, name: "target" }],
			optionalParameters: [
				{ type: CustomCommandParamType.Integer, name: "count" },
				{ type: CustomCommandParamType.String, name: "mob" },
			],
		},
		(origin, targets, countRaw, mobRaw) => {
			const src = origin?.sourceEntity;
			if (src && src.typeId === "minecraft:player" && !isAdminPlayer(src)) {
				return { status: CustomCommandStatus.Failure, message: "§c[Spawners] ❌ Admins only." };
			}
			if (!targets || targets.length === 0) {
				return { status: CustomCommandStatus.Failure, message: "§c[Spawners] No matching player found." };
			}
			const count = Math.max(1, Math.min(64, Math.floor(Number(countRaw) || 1)));
			const mobType = mobRaw
				? mobRaw.includes(":") ? mobRaw.toLowerCase() : `minecraft:${mobRaw.toLowerCase()}`
				: null;
			const label = mobRaw ? `${formatMobName(mobRaw)} Spawner` : "blank spawner";

			system.run(() => {
				for (const target of targets) {
					let item;
					if (mobType) {
						item = buildSpawnerItemStack({ mobType, count: 1, buffer: {} }, count);
					} else {
						item = new ItemStack(SPAWNER_ITEM_ID, count);
						item.nameTag = "§r§7Blank Spawner";
						item.setLore([
							"§r§8Place, then right-click with a",
							"§r§8spawn egg to configure its mob type.",
						]);
					}
					const container = target.getComponent("minecraft:inventory")?.container;
					if (container) container.addItem(item);
					else target.dimension.spawnItem(item, target.location);
					target.sendMessage(`§a[Spawners] ✔ You received ${count}x ${label}.`);
				}
			});
			return {
				status: CustomCommandStatus.Success,
				message: `§a[Spawners] ✔ Gave ${targets.map((t) => t.name).join(", ")} ${count}x ${label}.`,
			};
		}
	);
	console.warn("[DonutSMP Spawners] /sm:givespawner registered.");
	} catch (e) {
		console.error("[DonutSMP Spawners] FAILED to register /sm:givespawner:", e);
	}
}

export default { registerCommands };
