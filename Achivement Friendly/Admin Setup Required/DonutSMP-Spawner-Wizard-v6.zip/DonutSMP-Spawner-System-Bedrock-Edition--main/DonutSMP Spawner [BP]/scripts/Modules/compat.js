/**
 * compat.js — @minecraft/server 2.x turned Player#isOp and Entity#isValid /
 * Player#isValid from properties into METHODS. A bare `player.isOp` is then a
 * function reference, which is always truthy (everyone would count as OP), so
 * always go through these helpers.
 */
import * as mc from "@minecraft/server";
import { ADMIN_GAMERTAGS } from "../Spawnersys/spawner_config.js";

/** Describes how a player's operator status was read (for diagnostics). */
export function describeOp(player) {
	const parts = [];
	try {
		parts.push(`isOp=${typeof player.isOp === "function" ? player.isOp() : player.isOp}`);
	} catch (e) {
		parts.push("isOp=err");
	}
	try {
		parts.push(`commandLevel=${player.commandPermissionLevel}`);
	} catch (e) {
		parts.push("commandLevel=err");
	}
	try {
		parts.push(`playerLevel=${player.playerPermissionLevel}`);
	} catch (e) {
		parts.push("playerLevel=err");
	}
	return parts.join(", ");
}

/**
 * Real operator check. Newer @minecraft/server removed Player#isOp, so this
 * tries (in order): isOp() / isOp, commandPermissionLevel, playerPermissionLevel.
 */
export function isOpPlayer(player) {
	try {
		const v = player?.isOp;
		if (typeof v === "function") return !!player.isOp();
		if (typeof v === "boolean") return v;
	} catch {}
	try {
		const lvl = player?.commandPermissionLevel;
		if (lvl !== undefined && mc.CommandPermissionLevel) {
			const E = mc.CommandPermissionLevel;
			if (lvl !== E.Any && lvl !== 0) return true; // GameDirectors or higher
		}
	} catch {}
	try {
		const pl = player?.playerPermissionLevel;
		if (pl !== undefined && mc.PlayerPermissionLevel && pl === mc.PlayerPermissionLevel.Operator) return true;
	} catch {}
	return false;
}

/** Operator, OR carries the "admin" tag, OR is listed in ADMIN_GAMERTAGS. */
export function isAdminPlayer(player) {
	try {
		if (isOpPlayer(player)) return true;
		if (player.hasTag("admin")) return true;
		const n = String(player.name).toLowerCase();
		return ADMIN_GAMERTAGS.some((g) => String(g).toLowerCase() === n);
	} catch {
		return false;
	}
}

export function isAlive(obj) {
	try {
		const v = obj?.isValid;
		return typeof v === "function" ? !!obj.isValid() : !!v;
	} catch {
		return false;
	}
}
