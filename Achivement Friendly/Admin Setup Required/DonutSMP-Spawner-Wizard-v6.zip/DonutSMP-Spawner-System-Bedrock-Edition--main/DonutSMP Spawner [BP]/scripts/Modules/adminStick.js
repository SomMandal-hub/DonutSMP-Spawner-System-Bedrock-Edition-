/**
 * adminStick.js — one-time admin setup wizard.
 *
 * Admins get a locked "Spawner Admin Tool" stick (can't be dropped, moved out of
 * the inventory, or lost on death). Tapping it opens a setup form with up to 3
 * steps:
 *   1. Add the admin tag            (hidden once you have the tag)
 *   2. Spawners + one spawn egg for EVERY mob in the loot table
 *      (spawner count == number of eggs; both follow the loot table live)
 *   3. Diamond pickaxe + anvil + Silk Touch book
 * Finished steps disappear from the menu; the stick STAYS. Progress is recorded
 * against a signature of the CURRENT loot table, so if the loot table later
 * gains or loses a mob, steps 2-3 reappear to be run again (step 1 stays hidden
 * because you already have the tag).
 * Below the steps there is always a "Give configured spawner" section (mob,
 * amount, player name — blank = yourself) since slash commands aren't usable
 * in cheats-off, achievement-friendly worlds.
 */
import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import { isAdminPlayer, describeOp } from "./compat.js";
import { ADMIN_DIAGNOSTICS, SHOW_GIVE_CONFIGURED_SPAWNER_BUTTON } from "../Spawnersys/spawner_config.js";
import { SPAWNER_ITEM_ID, buildSpawnerItemStack, formatMobName } from "../Spawnersys/spawner_vanilla.js";
import { getSupportedMobTypes } from "../Spawnersys/spawner_loot.js";

const { world, system, ItemStack, ItemLockMode, EnchantmentTypes } = mc;

const STICK_ID = "minecraft:stick";
export const STICK_NAME = "§r§6§lSpawner Admin Tool";
const STICK_LORE = ["§r§7Admins only.", "§r§8Tap to open the setup menu."];

const PROG_KEY = "dsmp_setup_progress"; // JSON { sig, items, tools }

// ── Loot-table sync ───────────────────────────────────────────────────
function eggMobs() {
	const out = [];
	for (const mob of getSupportedMobTypes()) {
		try {
			new ItemStack(`${mob}_spawn_egg`, 1);
			out.push(mob);
		} catch {
			/* this mob has no spawn egg (e.g. iron golem) — skipped */
		}
	}
	return out;
}

function lootSignature() {
	const s = getSupportedMobTypes().slice().sort().join(",");
	let h = 5381;
	for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
	return `${getSupportedMobTypes().length}:${(h >>> 0).toString(36)}`;
}

// ── Per-player progress ───────────────────────────────────────────────
function getProgress(player) {
	const sig = lootSignature();
	try {
		const raw = player.getDynamicProperty(PROG_KEY);
		if (typeof raw === "string") {
			const p = JSON.parse(raw);
			if (p?.sig === sig) return p;
		}
	} catch {}
	return { sig, items: false, tools: false }; // stale/new signature => fresh run
}

function saveProgress(player, p) {
	try {
		player.setDynamicProperty(PROG_KEY, JSON.stringify(p));
	} catch (e) {
		console.warn("[AdminStick] saveProgress failed:", e);
	}
}

// ── Stick ─────────────────────────────────────────────────────────────
function isAdminStick(item) {
	return !!item && item.typeId === STICK_ID && item.nameTag === STICK_NAME;
}

function buildStick() {
	const stick = new ItemStack(STICK_ID, 1);
	stick.nameTag = STICK_NAME;
	stick.setLore(STICK_LORE);
	stick.lockMode = ItemLockMode.inventory;
	stick.keepOnDeath = true;
	return stick;
}

function removeSticks(player) {
	const container = player.getComponent("minecraft:inventory")?.container;
	if (!container) return;
	for (let i = 0; i < container.size; i++) {
		if (isAdminStick(container.getItem(i))) container.setItem(i, undefined);
	}
}

// Admins keep exactly one stick; everyone else has none.
function syncStick(player) {
	try {
		const container = player.getComponent("minecraft:inventory")?.container;
		if (!container) return;
		const wants = isAdminPlayer(player);
		let found = 0;
		for (let i = 0; i < container.size; i++) {
			if (!isAdminStick(container.getItem(i))) continue;
			found++;
			if (!wants || found > 1) container.setItem(i, undefined);
		}
		if (wants && found === 0 && container.emptySlotsCount > 0) container.addItem(buildStick());
	} catch (e) {
		console.warn("[AdminStick] syncStick failed:", e);
	}
}

function freeSlots(player) {
	return player.getComponent("minecraft:inventory")?.container?.emptySlotsCount ?? 0;
}

function giveItem(player, item) {
	const container = player.getComponent("minecraft:inventory")?.container;
	const leftover = container ? container.addItem(item) : item;
	if (leftover) player.dimension.spawnItem(leftover, player.location);
}

// ── Steps ─────────────────────────────────────────────────────────────
function doStep2(player) {
	const mobs = eggMobs();
	const n = mobs.length;
	const stacks = Math.ceil(n / 64);
	const need = n + stacks;
	if (freeSlots(player) < need) {
		player.sendMessage(`§c[Admin] Free up at least ${need} inventory slots first (need ${need}, have ${freeSlots(player)}).`);
		return false;
	}
	let left = n;
	while (left > 0) {
		const take = Math.min(64, left);
		const sp = new ItemStack(SPAWNER_ITEM_ID, take);
		sp.nameTag = "§r§7Blank Spawner";
		sp.setLore(["§r§8Place, then right-click with a", "§r§8spawn egg to configure its mob type."]);
		giveItem(player, sp);
		left -= take;
	}
	for (const mob of mobs) giveItem(player, new ItemStack(`${mob}_spawn_egg`, 1));
	player.sendMessage(`§a[Admin] ✔ Gave ${n}x mob_spawner + ${n} spawn eggs (one per loot-table mob).`);
	return true;
}

function doStep3(player) {
	if (freeSlots(player) < 3) {
		player.sendMessage(`§c[Admin] Free up at least 3 inventory slots first (have ${freeSlots(player)}).`);
		return false;
	}
	giveItem(player, new ItemStack("minecraft:diamond_pickaxe", 1));
	giveItem(player, new ItemStack("minecraft:anvil", 1));
	// The enchantable component needs a real EnchantmentType object
	// (EnchantmentTypes.get) — passing a plain string leaves the book blank.
	const book = new ItemStack("minecraft:enchanted_book", 1);
	try {
		const comp = book.getComponent("enchantable");
		const silk = EnchantmentTypes.get("silk_touch");
		if (!comp || !silk) throw new Error("enchantable component or silk_touch type unavailable");
		comp.addEnchantment({ type: silk, level: 1 });
	} catch (e) {
		console.warn("[AdminStick] couldn't enchant book:", e);
		player.sendMessage("§c[Admin] Couldn't enchant the Silk Touch book.");
	}
	giveItem(player, book);
	// Combining the book on the anvil costs XP levels, so hand over 4.
	try {
		player.addLevels(4);
	} catch (e) {
		console.warn("[AdminStick] addLevels failed:", e);
	}
	player.sendMessage("§a[Admin] ✔ Gave diamond pickaxe, anvil, Silk Touch book and 4 XP levels.");
	return true;
}

// ── UI ────────────────────────────────────────────────────────────────
function makeObservable(value) {
	const opts = { clientWritable: true };
	if (ui.Observable?.create) return ui.Observable.create(value, opts);
	const Ctor =
		typeof value === "boolean" ? ui.ObservableBoolean : typeof value === "number" ? ui.ObservableNumber : ui.ObservableString;
	return new Ctor(value, opts);
}
function makeReadOnlyObservable(value) {
	if (ui.Observable?.create) return ui.Observable.create(value);
	return new ui.ObservableString(value);
}
function makeForm(player, title) {
	return ui.CustomForm.create ? ui.CustomForm.create(player, title) : new ui.CustomForm(player, title);
}

const _open = new Map(); // player.id -> form

function openSetupMenu(player) {
	if (!isAdminPlayer(player)) {
		player.sendMessage("§c[Admin] Admins only.");
		return;
	}
	if (_open.has(player.id)) return;
	if (!ui.CustomForm) {
		player.sendMessage("§c[Admin] This game version doesn't support the live UI (CustomForm). Update @minecraft/server-ui in manifest.json.");
		return;
	}

	const prog = getProgress(player);
	const hasTag = player.hasTag("admin");
	const n = eggMobs().length;

	const summary = makeReadOnlyObservable(
		`§7Loot table: §e${getSupportedMobTypes().length} §7mobs  •  §e${n} §7eggs / spawners`
	);

	// Rebuild the form after a step so finished steps drop out of the menu.
	const reopen = () => {
		const f = _open.get(player.id);
		try {
			f?.close();
		} catch {}
		system.runTimeout(() => {
			_open.delete(player.id);
			openSetupMenu(player);
		}, 5);
	};

	const act = (fn) =>
		system.run(() => {
			try {
				if (fn()) reopen();
			} catch (e) {
				player.sendMessage(`§c[Admin] Failed: ${e}`);
			}
		});

	const form = makeForm(player, "§6Admin Setup").closeButton().label(summary);

	const pending = !hasTag || !prog.items || !prog.tools;
	if (pending) form.divider().label("§eSetup");
	else form.divider().label("§a✔ Setup complete");

	if (!hasTag) {
		form.button("1. Make me admin  (tag @s add admin)", () =>
			act(() => {
				player.addTag("admin");
				player.sendMessage("§a[Admin] ✔ tag @s add admin");
				return true;
			})
		);
	}
	if (!prog.items) {
		form.button(`2. Spawners + all spawn eggs  (${n} + ${n})`, () =>
			act(() => {
				if (!doStep2(player)) return false;
				saveProgress(player, { ...getProgress(player), items: true });
				return true;
			})
		);
	}
	if (!prog.tools) {
		form.button("3. Pickaxe + anvil + Silk Touch book + 4 XP levels", () =>
			act(() => {
				if (!doStep3(player)) return false;
				saveProgress(player, { ...getProgress(player), tools: true });
				return true;
			})
		);
	}

	// ── Give configured spawners (toggle: SHOW_GIVE_CONFIGURED_SPAWNER_BUTTON) ──
	if (SHOW_GIVE_CONFIGURED_SPAWNER_BUTTON) {
		const mobs = getSupportedMobTypes();
		const mobIndex = makeObservable(0);
		const amount = makeObservable(1);
		const target = makeObservable("");
		const preview = makeReadOnlyObservable("");
		const curMob = () => mobs[Math.max(0, Math.min(mobs.length - 1, Math.floor(mobIndex.getData())))];
		const curAmount = () => Math.max(1, Math.min(64, Math.floor(amount.getData())));
		const refresh = () => {
			const who = String(target.getData() ?? "").trim() || "yourself";
			preview.setData(`§7Gives §e${curAmount()}x ${formatMobName(curMob())} Spawner §7to §e${who}`);
		};
		mobIndex.subscribe(refresh);
		amount.subscribe(refresh);
		target.subscribe(refresh);
		refresh();

		form
			.divider()
			.label("§eGive configured spawner")
			.dropdown(
				"Mob type",
				mobIndex,
				mobs.map((m, i) => ({ label: formatMobName(m), value: i }))
			)
			.slider("Amount", amount, 1, 64, { step: 1 })
			.textField("Player name (blank = yourself)", target)
			.label(preview)
			.button("Give configured spawner", () =>
				system.run(() => {
					try {
						const name = String(target.getData() ?? "").trim();
						const who = name
							? world.getPlayers().find((p) => p.name.toLowerCase() === name.toLowerCase())
							: player;
						if (!who) {
							player.sendMessage(`§c[Admin] Player "${name}" not found or offline.`);
							return;
						}
						const mob = curMob();
						const count = curAmount();
						const item = buildSpawnerItemStack({ mobType: mob, count: 1, buffer: {} }, count);
						giveItem(who, item);
						player.sendMessage(`§a[Admin] ✔ Gave ${who.name} ${count}x ${formatMobName(mob)} Spawner.`);
						if (who !== player) who.sendMessage(`§a[Spawners] ✔ You received ${count}x ${formatMobName(mob)} Spawner.`);
					} catch (e) {
						player.sendMessage(`§c[Admin] Failed: ${e}`);
					}
				})
			);
	}

	_open.set(player.id, form);
	form
		.show()
		.catch((e) => console.warn("[AdminStick] form error:", e))
		.finally(() => {
			if (_open.get(player.id) === form) _open.delete(player.id);
		});
}

export function registerAdminStick() {
	world.afterEvents.itemUse.subscribe((event) => {
		if (!isAdminStick(event.itemStack)) return;
		openSetupMenu(event.source);
	});

	world.afterEvents.playerSpawn.subscribe((event) => {
		const player = event.player;
		syncStick(player);
		if (event.initialSpawn && ADMIN_DIAGNOSTICS && !isAdminPlayer(player)) {
			system.runTimeout(() => {
				try {
					player.sendMessage(
						`§e[Admin] No Admin Tool given — not detected as admin (${describeOp(player)}). ` +
							`To get it, add "${player.name}" to ADMIN_GAMERTAGS in spawner_config.js.`
					);
				} catch {}
			}, 60);
		}
	});

	// Re-checks every 2s: gives the stick when the loot table changes, removes it
	// for finished/non-admin players.
	system.runInterval(() => {
		for (const player of world.getPlayers()) syncStick(player);
	}, 40);
}

export default { registerAdminStick };
