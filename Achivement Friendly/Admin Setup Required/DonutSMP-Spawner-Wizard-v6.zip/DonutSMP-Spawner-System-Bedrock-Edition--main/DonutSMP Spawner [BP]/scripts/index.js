/**
 * DonutSMP Spawner System
 * Entry point for standalone Behavior Pack.
 */
import { system } from "@minecraft/server";
import { initSpawnerSystem } from "./Spawnersys/spawner_init.js";
import { registerCommands } from "./Spawnersys/spawner_admin.js";

// Custom commands can ONLY be registered during the startup event, and that
// subscription must happen at module load (not inside system.run).
system.beforeEvents.startup.subscribe((startupEvent) => {
    registerCommands(startupEvent);
});

// Initialize DonutSMP Spawner System after world is ready to prevent early execution errors
system.run(() => {
    initSpawnerSystem();
    console.log("§a✔ [DonutSMP Spawners] System successfully initialized!");
});
